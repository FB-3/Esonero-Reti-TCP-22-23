/*
 ============================================================================
 Name        : Server.c
 Author      : Basile Federico 759524
 Version     : 1.0
 Copyright   : //
 Description : TCP Server Exam
 ============================================================================
 */

#include "..\..\Protocol&Operations\src\protocol.h"
#include "..\..\Protocol&Operations\src\operations.h"
#define QLEN 5


int main(int argc, char *argv[]) {

	int port;
	char * server_address = "";

	if(argc > 1) {

		server_address = argv[1];
		port = atoi(argv[2]);
	}
	else {

		port = PROTOPORT;
		server_address = LOCAL_HOST_ADDRESS;
	}

#if defined WIN32
	if(winCreateSock() == 0) {

		return -1;
	}
#endif

	int my_socket;

	my_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

	if(my_socket < 0) {

		errorhandler("Server: Socket creation failed. \n");
		clearWinsock();
		return -1;
	}

	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));

	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(server_address);
	sad.sin_port = htons(port);

	if(bind(my_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {

		errorhandler("Server: bind() failed. \n");
		closesocket(my_socket);
		return -1;
	}


	if(listen(my_socket, QLEN) < 0) {

		errorhandler("Server: listen() failed. \n");
		closesocket(my_socket);
		clearWinsock();
		return -1;
	}

	struct sockaddr_in cad;
	int client_socket;
	int client_len;
	puts("Waiting for a client to connect... \n");


	while(1) {	// Server doesn't close its connection

		client_len = sizeof(cad);

		if((client_socket = accept(my_socket, (struct sockaddr*) &cad, &client_len)) < 0) {

			errorhandler("Server: accept() failed. \n");
			closesocket(my_socket);
			clearWinsock();
			return -1;
		}

		printf("Connection established with %s:%d\n", inet_ntoa(cad.sin_addr), ntohs(cad.sin_port));

		char op_buf[BUFFER_SIZE];
		int bytes_rcvd;
		char operator = 0;

		do {

			memset(op_buf, 0, BUFFER_SIZE);

			if ((bytes_rcvd = recv(client_socket, op_buf, BUFFER_SIZE - 1, 0)) <= 0) {

					errorhandler("Server: recv() failed or connection closed prematurely. \n");
					closesocket(client_socket);
					clearWinsock();
					return -1;
			}

			printf("Received espression: %s\n", op_buf);

			char * token = NULL;

			token = strtok(op_buf, " ");
			operator = *token;

			if(operator != '=') {

				token = strtok(NULL, " ");
				char operand1_buf[(BUFFER_SIZE - 2)/2];	// Store at most 126 characters
				strcpy(operand1_buf, token);

				token = strtok(NULL, " ");
				char operand2_buf[(BUFFER_SIZE - 2)/2]; // Store at most 126 characters
				strcpy(operand2_buf, token);

				char result[BUFFER_SIZE];		// Answer to client
				memset(result, 0, BUFFER_SIZE); // Cleans result buffer
				int res_len;

				int operand1;
				sscanf(operand1_buf, "%d", &operand1);

				int operand2;
				sscanf(operand2_buf, "%d", &operand2);


				if(!isdigit(*operand1_buf) || !isdigit(*operand2_buf)) {	// Checks if one of the two operands is a character

					strcpy(result, "Non-digit operand detected. Operation is not possible.");
					res_len = strlen(result);

					if (send(client_socket, result, res_len, 0) != res_len) {

						errorhandler("Server: send() sent a different number of bytes than expected. \n");
						closesocket(client_socket);
						clearWinsock();
						return -1;
					}
				}
				else if(operator == '+' || operator == '-' || operator == '*' || operator == '/') {

					switch(operator) {

							case '+':

								sprintf(result, "%d", sum(operand1, operand2));
								res_len = strlen(result);

								if (send(client_socket, result, res_len, 0) != res_len) {

									errorhandler("Server: send() sent a different number of bytes than expected. \n");
									closesocket(client_socket);
									clearWinsock();
									return -1;
								}
								break;

							case '-':

								sprintf(result, "%d", subtraction(operand1, operand2));
								res_len = strlen(result);

								if (send(client_socket, result, res_len, 0) != res_len) {

									errorhandler("Server: send() sent a different number of bytes than expected. \n");
									closesocket(client_socket);
									clearWinsock();
									return -1;
								}
								break;

							case '*':

								sprintf(result, "%d", multiplication(operand1, operand2));
								res_len = strlen(result);

								if (send(client_socket, result, res_len, 0) != res_len) {

									errorhandler("Server: send() sent a different number of bytes than expected. \n");
									closesocket(client_socket);
									clearWinsock();
									return -1;
								}
								break;

							case '/':

								if(operand2 == 0) {		// A/B where B = 0 error

									strcpy(result, "Divide by 0 error recognized. Impossible operation.");
									res_len = strlen(result);

								}
								else {

									sprintf(result, "%.2f", division(operand1, operand2)); // Result with 2 decimal digit
									res_len = strlen(result);
								}

								if (send(client_socket, result, res_len, 0) != res_len) {

									errorhandler("Server: send() sent a different number of bytes than expected. \n");
									closesocket(client_socket);
									clearWinsock();
									return -1;
								}
								break;

					}
				}
				else {

					strcpy(result, "Not recognized operation.");	// Wrong operator inserted
					res_len = strlen(result);

					if (send(client_socket, result, res_len, 0) != res_len) {

						errorhandler("Server: send() sent a different number of bytes than expected");
						closesocket(client_socket);
						clearWinsock();
						return -1;
					}

				}
			}

		} while(operator != '=');	// Stop receiving expression from that specific client

		puts("");
	}
}
