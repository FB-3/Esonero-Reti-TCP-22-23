/*
 ============================================================================
 Name        : Client.c
 Author      : Basile Federico 759524
 Version     : 1.0
 Copyright   : //
 Description : TCP Client Exam
 ============================================================================
 */

#include "..\..\Protocol&Operations\src\protocol.h"

int main(int argc, char *argv[]) {

	int port;
	char * connect_address = "";

	if(argc > 1) {

		connect_address = argv[1];
		port = atoi(argv[2]);
	}
	else {

		port = PROTOPORT;
		connect_address = LOCAL_HOST_ADDRESS;

	}

#if defined WIN32
	if(winCreateSock() == 0) {

		return -1;
	}
#endif

	int client_socket;

	client_socket = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);

	if (client_socket < 0) {

		errorhandler("Client: Socket creation failed. \n");
		clearWinsock();
		return -1;
	}

	struct sockaddr_in sad;
	memset(&sad, 0, sizeof(sad));

	sad.sin_family = AF_INET;
	sad.sin_addr.s_addr = inet_addr(connect_address);
	sad.sin_port = htons(port);

	printf("Connecting to %s:%d\n", connect_address, port);

	if (connect(client_socket, (struct sockaddr*) &sad, sizeof(sad)) < 0) {

		errorhandler("Client: Failed to connect. \n");
		closesocket(client_socket);
		clearWinsock();
		return -1;
	}

	puts("Connected.\n");

	char expression[BUFFER_SIZE];

	do {

		memset(expression, 0, BUFFER_SIZE);

		printf("Insert an expression: (Close connection =, Addition +, Subtraction -, Multiplication *, Division /)\n");
		printf("Expression be like: + 23 45\n%c", '>');
		gets(expression);

		int exp_lenght = strlen(expression);

		if(send(client_socket, expression, exp_lenght, 0) != exp_lenght) {

				errorhandler("Client: send() sent a different number of bytes than expected");
				closesocket(client_socket);
				clearWinsock();
				return -1;
		}

		if (strchr(expression, '=') == NULL) {

			int bytes_rcvd;
			char result[BUFFER_SIZE];
			memset(result, 0, BUFFER_SIZE);

			if ((bytes_rcvd = recv(client_socket, result, BUFFER_SIZE - 1, 0)) <= 0) {

					errorhandler("Client: recv() failed or connection closed prematurely");
					closesocket(client_socket);
					clearWinsock();
					return -1;
			}

			printf("Result: %s\n\n", result);
		}

	} while(expression[0] != '=');

	closesocket(client_socket);
	clearWinsock();
}
